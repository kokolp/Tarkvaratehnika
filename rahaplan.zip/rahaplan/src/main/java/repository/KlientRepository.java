package repository;

import org.springframework.data.repository.CrudRepository;

import rahaplaneerija.model.Klient;

public interface KlientRepository extends CrudRepository<Klient, Integer> {
    Klient findByName(String nimi);
}