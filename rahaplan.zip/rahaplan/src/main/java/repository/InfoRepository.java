package repository;

import org.springframework.data.repository.CrudRepository;

import rahaplaneerija.model.KliendInfo;


	public interface InfoRepository extends CrudRepository<KliendInfo, Integer> {
	    KliendInfo findByName(String name);

		

}
