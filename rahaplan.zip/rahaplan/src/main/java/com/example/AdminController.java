package com.example;


import java.security.Principal;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@Controller
public class AdminController {
	@RequestMapping(value = "/admin", method = RequestMethod. GET)
	 public String welcomeAdmin(ModelMap model, Principal principal) {
	  String uname = principal.getName();
	  model.addAttribute("author", uname);
	  model.addAttribute("message", "Hello Spring Security - ADMIN PAGE");
	  return "kliendileht";

	 }

	 @RequestMapping(value = "/avaleht", method = RequestMethod.GET)
	 public String printMessage(ModelMap model, Principal principal) {

	  String uname = principal.getName();
	  model.addAttribute("author", uname);
	  model.addAttribute("message", "Hello Spring Security - USER LOGIN");
	  return "kliendileht";
	 }
	 
	 @RequestMapping(value = "/403", method = RequestMethod.GET)
	 public String accessDenied(ModelMap model, Principal principal) {
	  String uname = principal.getName();
	  model.addAttribute("message", "Sorry "+uname+" You don't have privileges to VIEW this page!!!");
	  return "403";
	 }

	


	public AdminController() {
		// TODO Auto-generated constructor stub
	}

}
