package com.example;

import org.apache.log4j.spi.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.sun.istack.internal.logging.Logger;
@Controller
public class MyController {

	
		@RequestMapping("/")
	    public String handler (Model model) {
	        model.addAttribute("msg","Tere");
	        return "avaleht";
	    }
		
		  //private static final Logger logger = LoggerFactory.getLogger(MyController.class);
		  
		    @RequestMapping(value = "/reg")
		    public String indexPage() {
		        return "reg";
		    }
		 
		    @RequestMapping(value = "/klient")
		    public String klientPage() {
		        return "kliendileht";
		    }
		 
		    @RequestMapping(value ="/klient", method = RequestMethod. GET)
		    public ModelAndView login(@RequestParam(value = "error", required = false) String error) {
		        ModelAndView model = new ModelAndView();
		        if (error != null) {
		            model.addObject("error", "vale kasutajanimi voi parool!");
		        }
		        model.setViewName("Esileht");
		        return model;
		 
		    }
		 
		
	}


