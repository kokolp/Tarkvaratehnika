package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.web.ErrorMvcAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;

import sun.applet.Main;





@SpringBootApplication(exclude = ErrorMvcAutoConfiguration.class )
public class RahaplanApplication {
	
	 protected SpringApplicationBuilder configure (SpringApplicationBuilder builder) {
	        return builder.sources(Main.class);
	    }

	public static void main(String[] args) {
		SpringApplication.run(RahaplanApplication.class, args);
		
	}
	
	//@Autowired
	
	 @Autowired
	 public void ConfigureGlobal(AuthenticationManagerBuilder auth) throws Exception{
	 		
	 		auth.inMemoryAuthentication().withUser("user").password("password").roles("user");
	 	}


	
}
