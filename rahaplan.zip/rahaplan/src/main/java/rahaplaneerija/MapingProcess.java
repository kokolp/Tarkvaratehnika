package rahaplaneerija;

import rahaplaneerija.model.Klient;
import rahaplaneerija.model.KliendInfo;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.javafx.collections.MappingChange.Map;

public class MapingProcess implements KlientServices {

	public MapingProcess() {
		
		private Map<String,Klient> andmedKlient;
		
		private Map<String,KliendInfo> andmedKliendInfo;
		
		public Map<String,Klient> getAndmedKlient() {
		return andmedKlient;
		}
		
		
		
		public void setAndmedKlient(Map<String,Klient> andmedKlient) {
		this.andmedKlient = andmedKlient;
		}
		
		
		
		public Map<String,KliendInfo> getAndmedKliendInfo() {
		return andmedKliendInfo;
		}
		public void setAndmedKliendInfo(Map<String,KliendInfo> andmedKliendInfo) {
		this.andmedKliendInfo = andmedKliendInfo;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public Klient getKlient(String ID) {
		// TODO Auto-generated method stub
		return null;
	}

}
