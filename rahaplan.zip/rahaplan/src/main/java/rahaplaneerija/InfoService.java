package rahaplaneerija;

import org.springframework.boot.autoconfigure.domain.EntityScan;

import com.sun.xml.internal.bind.v2.schemagen.xmlschema.List;

import rahaplaneerija.model.KliendInfo;

@EntityScan
public interface InfoService {
	InfoService INSTANCE_INFO= new InfoServiceImpl();
    List<KliendInfo> getInfo();
    KliendInfo getById(String ID);
}
