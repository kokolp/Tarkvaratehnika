package rahaplaneerija;

import rahaplaneerija.model.Klient;
//import rahaplaneerija.model.KliendInfo;

public interface KlientServices {
	public Klient getKlient(String ID);

}
