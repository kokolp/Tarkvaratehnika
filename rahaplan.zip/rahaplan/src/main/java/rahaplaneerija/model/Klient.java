package rahaplaneerija.model;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import java.io.Serializable;
import java.util.concurrent.atomic.AtomicLong;
 
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.PersistenceConstructor;


@EntityScan

@Table(name="klient")
public class Klient  {
	 private static final long serialVersionUID = 1L;
        @Autowired
		@ID
		@GeneratedValue(Strategi=GenerationType.AUTO)
		int ID;
        private String uname;
        private String psw;
    	private String nimi;
    	private String per_nimi;
    	private String adress;
    	private String telefon;
    	private String role;
    	private String infoID;
    	private static AtomicLong COUNTER = new AtomicLong(0L);	
    	
    	@PersistenceConstructor
        public Klient() {
            this.ID = COUNTER.incrementAndGet();
        }
    	 @Override
    	    public String toString() {
    	        return String.format("Klient[ID=%d, nimi='%s', per_nimi='%s']", ID, nimi, per_nimi);
    	    }
    	 
	//public Klient() {
		// TODO Auto-generated constructor stub
	//}
		
		int getID() 
		 {
			return this.ID; 
		 }
		public void setID(int ID)
		{
			this.ID = ID; 
		}

		//@Column (name="uname")
		
		
		public String getUname() {
			return uname; 
			}
		@Autowired
		public void setUname(String uname)
		{
			this.uname = uname; 
		}

		//@Column (name="psw")
		
		public String getPsw() 
		{
			return psw;
		}
		public void setPsw(String psw)
		{ 
			this.psw = psw;
		}
		
		//@Column (name="nimi")
	
		
		public String getNimi()
		{
			return nimi;
		}
		public void setNimi(String nimi)
		{ 
			this.nimi = nimi;
		}

		///@Column (name="per_nimi")
		
		
		public String getPer_nimi() {
			return per_nimi; 
			}
		public void setPer_nimi(String per_nimi)
		{
			this.per_nimi = per_nimi; 
		}
		
		//@Column (name="adress")
	
		
		public String getAdress() {
			return adress; 
			}
		public void setAdress(String adress)
		{
			this.adress = adress; 
		}

		//@Column (name="telefon")
		
		
		public String getTelefon() {
			return telefon; 
			}
		public void setTelefon(String telefon)
		{
			this.telefon = telefon; 
		}
		
		//@Column (name="role")
		
		
		public String getRole() {
			return role; 
			}
		public void setRole ( String role)
		{
			this.role = role; 
		}

		//@Column (name="infoID")
		
		
		public String getInfoID() {
			return  infoID; 
			}
		
		public void setInfoID(String  infoID)
		{
			this.infoID = infoID; 
		}
	
	
	
	//@Override
	
	//public static void main(String[] args) {
		
	   
	       // return "Klient{" +
	           //     ", uname='" + uname + '\'' +
	            //    ", psw=" + psw +
	            //    '}';
	  //  }
	
	}

