package rahaplaneerija.model;




import static java.lang.annotation.RetentionPolicy.RUNTIME;

//import javax.servlet.jsp.tagext.* ;
//import javax.servlet.jsp.* ;
import java.io.* ;
import java.util.Set;
import java.io.IOException;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.annotation.Id;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.classmate.GenericType;

import javax.annotation.Generated;
import javax.persistence.Entity;
import javax.persistence.Generated;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;



@Entity
@Table(name="info")
public class KliendInfo {

	

	public KliendInfo() {
		@ID
		@GeneratedValue
	
		Long ID;
		
		@Column (name="InfoID")
		String InfoID;
		public String getInfoID() {
			return InfoID; 
			}
		@Autowired
		public void setInfoID(String InfoID)
		{
			this.InfoID = InfoID; 
		}

		@Column (name="InfoCategory")
		String InfoCategory;
		public String getInfoCategory() {
			return InfoCategory; 
			}
		@Autowired
		public void setInfoCategory(String InfoCategory)
		{
			this.InfoCategory = InfoCategory; 
		}
		
		@Column (name="InfoNimi")
		String InfoNimi;
		public String getInfoNimi() {
			return InfoNimi; 
			}
		@Autowired
		public void setInfoNimi(String InfoNimi)
		{
			this.InfoNimi = InfoNimi; 
		}

		@Column (name="EeldatavSumm")
		private BigDecimal EeldatavSumm;
		public String getEeldatavSumm() {
			return EeldatavSumm; 
			}
		@Autowired
		public void setEeldatavSumm(BigDecimal EeldatavSumm)
		{
			this.EeldatavSumm = EeldatavSumm; 
		}
		
		@Column (name="TegelikSumm")
		private BigDecimal TegelikSumm;
		public String getTegelikSumm() {
			return TegelikSumm; 
			}
		@Autowired
		public void setTegelikSumm(BigDecimal TegelikSumm)
		{
			this.TegelikSumm = TegelikSumm; 
		}
		
		@Column (name="Date")
				String Date;
				public String getDate() {
					return Date; 
					}
				@Autowired
				public void setDate(String Date)
				{
					this.Date = Date; 
				}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
