package rahaplaneerija;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jayway.jsonpath.Criteria;
import com.sun.xml.internal.bind.v2.schemagen.xmlschema.List;

import rahaplaneerija.model.KliendInfo;
import repository.InfoRepository;
@Service
public class InfoServiceImpl implements InfoService {
	
	
	private InfoRepository infoRepository;
	private InfoForm   infoForm;
	
	@Autowired
	public InfoServiceImpl(InfoRepository infoRepository,InfoForm   infoForm){
		this.infoRepository=infoRepository;
		this.infoForm=infoForm;
		
		
	}
   @Override	
   public List<KliendInfo> ListAll() {
    List<KliendInfo> info  = new ArrayList<>();
    InfoRepository.findAll().forEach(info :: add);
       return info;
    }


@Override
public KliendInfo getById(String ID) {
	// TODO Auto-generated method stub
	return  InfoRepository.findOne(ID);;
}

}
