
<?php

$connect= mysqli_connect("localhost","euroinve_turg","gmiCyVqXQ","euroinve_turg");

$data = json_decode(file_get_contents("php://input"));
 

if(count($data)>0){
                                
                                 $uemail= mysqli_real_escape_string($connect,$data->uuspsw);
                                 
                                 $password=str_shuffle($uemail);

$query="UPDATE `Klient` SET `password`='$password' WHERE `email`='$uemail' ";


if(mysqli_query($connect,$query))
{
echo "Uus parool saadetud emaile";
}
else
{
echo "Error";
}
}

?>

