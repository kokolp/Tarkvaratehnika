

$connect= mysqli_connect("localhost","euroinve_turg","gmiCyVqXQ","euroinve_turg");

$data = json_decode(file_get_contents("php://input"));

if(count($data)>0){
                                 $InfoCategory= mysqli_real_escape_string($connect,$data->kulutulu);
                                 $InfoNimi= mysqli_real_escape_string($connect,$data->liik);
                                 $EeldatavSumm= mysqli_real_escape_string($connect,$data->summa);
                                 $TegelikSumm= mysqli_real_escape_string($connect,$data->summa2);
                                 

$query="INSERT INTO `Info` (`InfoCategory`, `InfoNimi`, `EeldatavSumm`,`TegelikSumm`) VALUES ('$InfoCategory','$InfoNimi','$EeldatavSumm','$TegelikSumm')";
if(mysqli_query($connect,$query))
{
echo "Salvestatud";
}
else
{
echo "Viga";
}
}


/**
 * 
 */