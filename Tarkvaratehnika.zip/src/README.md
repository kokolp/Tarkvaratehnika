# Tarkvaratehnika
Projekt aines tarkvaratehnika

Link Google Drive'le: https://drive.google.com/drive/folders/0Bx0aY4YWbWRtc2RNRFFnOVdBZTQ?usp=sharing
