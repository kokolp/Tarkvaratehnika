package rahaplaneerija;

import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

public class Reg {

	public Reg() {
		// TODO Auto-generated constructor stub
	}
  public static void connection(){
	  
	  try{
		  Class.forName("org.mariadb.jdbc.Driver");
	  }
	  catch(ClassNotFoundException e)
				  {
					  e.printStackTrace();
				  }
	  
  }
  
  public static void ConnectToMySql(String email, String password_1, String nimi, String pernimi, String adress,String telefon) {
	  connection();
	  String host="jdbc:mariadb://localhost/test";
	  String username="root";
	  String password="root";
		try{
			Connection connect=DriverManager.getConnection(host,username,password);
			PreparedStatement statement=(PrepareStatement) connect.prepareStatement("INSERT INTO klient (email,password_1,nimi,pernimi,adress,telefon) VALUES(?,?,?,?,?,?)");
			Statement.setString(1,email);
			Statement.setString(2,password_1);
			Statement.setString(3,nimi);
			Statement.setString(4,pernimi);
			Statement.setString(5,adress);
			Statement.setString(6,telefon);
			
			Statement.executeUpdate();
			Statement.close();
			
			System.out.println("Works:");
		}
		catch(SQLException e){
			e.printStackTrace();
		}

	}

  
	public static void main(String[] args) {
		// TODO Auto-generated method stub
      ConnectToMySql("silli","milli","silli@milli.lo","jhgj","hhh","6565465");
	}

}
