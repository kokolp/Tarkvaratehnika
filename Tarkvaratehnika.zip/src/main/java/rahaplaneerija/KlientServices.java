package rahaplaneerija;

import rahaplaneerija.model.Klient;


public interface KlientServices {
	public Klient getKlient(String ID);

}
