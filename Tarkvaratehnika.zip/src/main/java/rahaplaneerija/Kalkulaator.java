package rahaplaneerija;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
/**
 * Servlet implementation class Registration
 */
@WebServlet("/Kalkulaator")
public class Kalkulaator extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Kalkulaator() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */

	@Override
	@Autowired
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		String date = request.getParameter("date"); 
		String liik = request.getParameter("liik"); 
		String summa = request.getParameter("summa");
		String summa2 = request.getParameter("summa2"); 
		String kulutulu = request.getParameter("kulutulu"); 
		String infoID = request.getParameter("infoID"); 
		
		
      try{
   	  Object con;
	//Statement  value = con.createStatment();
   	  //ResultSet value; 
   	   //int i = value.execute("INSERT INTO info VALUES ('"+infoID+"','"+kulutulu+"','"+liik+"','"+summa+"','"+summa2+"','"+infoID+"');");
   	   //con.commit();
		
		 //value.close();
  	   System.out.println("Olete registreerinud");
  	   
     }
     catch(Exception e){
  	  System.err.println("Proovige uuesti.");
  	   System.err.println(e);
  	   
  	   throw e;
     }
		
		
		
		response.sendRedirect("saastmisekalkulaator.html");
		
	}

	/**
	 * @see HttpServlet#doPut(HttpServletRequest, HttpServletResponse)
	 */
	@Override
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
