package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class dbManager {
	
	private Connection connection;
	private static dbManager dbManager;

	public dbManager() throws ClassNotFoundException, SQLException {
	    Class.forName("org.mariadb.jdbc.Driver");
	    connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "root");
	}

	public static  dbManager getdbManager() throws ClassNotFoundException, SQLException {
	    if (dbManager == null) {
	    	dbManager = new dbManager();
	    }
	    return dbManager;
	}

	public Connection getConnection() {
	    return connection;

	}
	}
