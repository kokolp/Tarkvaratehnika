// Custom Objects. This properties are setted by the server on runtime
interface Window {
  USER_NAME: string
  APPLICATION_URL_BASE: string
}
