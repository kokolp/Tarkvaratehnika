export function configure(framework){
    framework.globalResources('../converters/filter', '../converters/number')
}