export class Meist {
	
	 header = "Rahaplaneerija aitab kliendil näha, kui palju ja millistele toodetele on tema raha kulunud.";
   content = "Klient pääseb rahaplaneerijasse läbi veebilehe.";
	 content2 = "";
	 
	 
}