export class Tingimused {
	
	 header = "Tingimused";
   content = " Kasutajana on Sul palju rohkem võimalusi - saad oma kulud salvestada, et saada terviklikum ülevaade, kuhu raha kaob.";
   content2 =" Kalkulaatori  kasutamine on imelihtne - sisesta eeldatud ning prognoositav kulu või tulu ning vajuta <Lisa!> ja sinu andmed kuvatakse.";
   
   }