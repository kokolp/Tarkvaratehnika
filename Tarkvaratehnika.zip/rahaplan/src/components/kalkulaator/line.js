export class Line {
	constructor(name, expectedSum, actualSum, type, date) {
		this.name = name;
		this.expectedSum = expectedSum;
		this.actualSum = actualSum;
		this.type = type;
	    this.date = date;
	}
}