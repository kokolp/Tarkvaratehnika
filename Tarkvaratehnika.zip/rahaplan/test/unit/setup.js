import 'aurelia-polyfills';
import {initialize} from 'aurelia-pal-browser';
initialize();
