insert into teste values (1, 'Hello World');
